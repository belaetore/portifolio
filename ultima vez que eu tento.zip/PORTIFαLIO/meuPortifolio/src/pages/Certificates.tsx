import { useState } from "react";
import { motion } from "framer-motion";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Award } from "lucide-react";

interface Certificate {
  id: number;
  title: string;
  issuer: string;
  date: string;
  image: string;
  duration?: string;
  credentialId?: string;
  credentialUrl?: string;
}

const Certificates = () => {
  const [certificates] = useState<Certificate[]>([
    {
      id: 1,
      title: "Competência Transversal - Segurança no Trabalho",
      issuer: "SENAI - Escola Gaspar Ricardo Junior",
      date: "07/10/2024",
      image: "/segurançanotrabalhoo.jpeg",
      duration: "14 horas",
      credentialId: "RG 57730676-5",
      credentialUrl: "/segurançanotrabalho.pdf"
    },
    {
      id: 2,
      title: "Algoritmos e estruturas de dados JavaScript",
      issuer: "freeCodeCamp",
      date: "20/03/2025",
      image: "/freecpde.jpeg",
      duration: "300 horas",
      credentialId: "javascript-algorithms-and-data-structures-v8",
      credentialUrl: "https://freecodecamp.org/certification/IsabelaEtore/javascript-algorithms-and-data-structures-v8"
    },
    {
      id: 3,
      title: "Privacidade e Proteção de Dados (LGPD)",
      issuer: "SENAI - Escola Gaspar Ricardo Junior",
      date: "22/05/2024",
      image: "/privacidade.jpeg",
      duration: "4 horas",
      credentialId: "RG 57730676-5",
      credentialUrl: "/CERTIFICADO%20LGPD.pdf"
    },
    {
      id: 4,
      title: "Economia Circular",
      issuer: "SENAI - Escola Gaspar Ricardo Junior",
      date: "02/10/2024",
      image: "/ecnonomia.jpeg",
      duration: "20 horas",
      credentialId: "RG 57730676-5",
      credentialUrl: "/economia%20circular.pdf"
    },
    {
      id: 5,
      title: "Desvendando o 5G",
      issuer: "SENAI - Escola Gaspar Ricardo Junior",
      date: "22/04/2024",
      image: "/desvendandoocinco.jpeg",
      duration: "15 horas",
      credentialId: "RG 57730676-5",
      credentialUrl: "/DESVENDANDO%20O%205G.pdf"
    },
  ]);

  return (
    <div className="container mx-auto px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-4xl md:text-5xl font-bold text-center mb-12 text-transparent bg-clip-text bg-gradient-to-r from-pink-500 to-pink-700">
          MEUS CERTIFICADOS
        </h1>

        <div className="relative px-10 mb-12">
          <Carousel className="w-full" opts={{ align: "start", loop: true }}>
            <CarouselContent>
              {certificates.map((cert) => (
                <CarouselItem key={cert.id} className="md:basis-1/2 lg:basis-1/3 p-2">
                  <div className="h-full">
                    <CertificateCard certificate={cert} />
                  </div>
                </CarouselItem>
              ))}
            </CarouselContent>
            <CarouselPrevious className="left-0 bg-white/60 border-pink-800/20 text-pink-600 hover:bg-pink-50 hover:text-pink-700" />
            <CarouselNext className="right-0 bg-white/60 border-pink-800/20 text-pink-600 hover:bg-pink-50 hover:text-pink-700" />
          </Carousel>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-12">
          {certificates.map((cert, index) => (
            <motion.div
              key={cert.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1, duration: 0.5 }}
            >
              <CertificateCard certificate={cert} />
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
};

const CertificateCard = ({ certificate }: { certificate: Certificate }) => {
  return (
    <Card className="overflow-hidden border-pink-800/20 bg-white hover:shadow-lg hover:shadow-pink-500/10 transition-all duration-300 h-full flex flex-col">
      <div className="relative h-48 overflow-hidden group">
        <img 
          src={certificate.image} 
          alt={`${certificate.title} certificate`} 
          className="w-full h-full object-contain transition-transform duration-500 group-hover:scale-105" 
        />
        <div className="absolute inset-0 bg-gradient-to-t from-white/80 to-transparent flex items-end">
          <div className="p-4">
            <span className="px-2 py-1 text-xs rounded-md bg-pink-600/80 text-white">
              {certificate.date}
            </span>
          </div>
        </div>
      </div>
      <CardHeader>
        <CardTitle className="text-lg text-pink-700">{certificate.title}</CardTitle>
        <CardDescription className="text-pink-900/70">{certificate.issuer}</CardDescription>
      </CardHeader>
      <CardContent className="flex-grow">
        {certificate.duration && (
          <p className="text-sm text-gray-600 mb-2">
            <span className="font-medium">Duração:</span> {certificate.duration}
          </p>
        )}
        {certificate.credentialId && (
          <p className="text-xs text-gray-500">
            <span className="font-medium">ID da Credencial:</span> {certificate.credentialId}
          </p>
        )}
      </CardContent>
      <CardFooter>
        <Button 
          variant="outline" 
          size="sm" 
          className="w-full border-pink-800/30 hover:bg-pink-50 text-pink-700"
          asChild
        >
          <a href={certificate.credentialUrl} target="_blank" rel="noopener noreferrer">
            <Award className="mr-2 h-4 w-4" />
            Verificar Credencial
          </a>
        </Button>
      </CardFooter>
    </Card>
  );
};

export default Certificates;
