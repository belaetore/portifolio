import { useState } from "react";
import { motion } from "framer-motion";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Mail, Github, Linkedin } from "lucide-react";
import { toast } from "@/components/ui/use-toast";

const formSchema = z.object({
  name: z.string().min(2, {
    message: "O nome precisa ter pelo menos 2 caracteres.",
  }),
  email: z.string().email({
    message: "Por favor, insira um endereço de email válido.",
  }),
  subject: z.string().min(5, {
    message: "O assunto precisa ter pelo menos 5 caracteres.",
  }),
  message: z.string().min(10, {
    message: "A mensagem precisa ter pelo menos 10 caracteres.",
  }),
});

type FormValues = z.infer<typeof formSchema>;

const Contact = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      subject: "",
      message: "",
    },
  });

  function onSubmit(values: FormValues) {
    setIsSubmitting(true);
    setTimeout(() => {
      console.log(values);
      toast({
        title: "Mensagem enviada!",
        description: "Obrigada pelo contato, responderemos em breve.",
      });
      form.reset();
      setIsSubmitting(false);
    }, 1500);
  }

  const socialLinks = [
    {
      name: "Email",
      icon: Mail,
      link: "mailto:isabela.etore.dev2024@gmail.com",
      label: "isabela.etore.dev2024@gmail.com"
    },
    {
      name: "GitHub",
      icon: Github,
      link: "https://github.com/belaetore",
      label: "github.com/belaetore"
    },
    {
      name: "LinkedIn",
      icon: Linkedin,
      link: "https://linkedin.com/in/seu-usuario", // Substitua pelo seu LinkedIn
      label: "linkedin.com/in/seu-usuario" // Substitua pelo seu LinkedIn
    }
  ];

  return (
    <div className="container mx-auto px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-4xl md:text-5xl font-bold text-center mb-12 text-transparent bg-clip-text bg-gradient-to-r from-pink-400 to-pink-700">
          ENTRE EM CONTATO
        </h1>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Redes sociais */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2, duration: 0.5 }}
          >
            <Card className="h-full bg-[#ff007f] border-[#ff007f] text-white">
              <CardHeader>
                <CardTitle className="text-white">REDES SOCIAIS</CardTitle>
                <CardDescription className="text-pink-100/90">
                  Você pode me encontrar através das seguintes plataformas:
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {socialLinks.map((social) => (
                  <a
                    key={social.name}
                    href={social.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center p-4 rounded-lg border border-white/20 hover:bg-white/10 transition-colors group"
                  >
                    <div className="mr-4 p-2 rounded-full bg-white/10 text-white group-hover:bg-white/20 transition-colors">
                      <social.icon size={24} />
                    </div>
                    <div>
                      <h3 className="font-medium">{social.name}</h3>
                      <p className="text-sm text-white/70">{social.label}</p>
                    </div>
                  </a>
                ))}

                <div className="mt-8 p-4 rounded-lg border border-white/20 bg-white/10">
                  <h3 className="font-medium mb-2">Horário de disponibilidade</h3>
                  <p className="text-sm text-white/70">
                    Segunda a Sexta: 09:00 - 18:00<br />
                    Resposta em até 48 horas úteis
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Formulário */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4, duration: 0.5 }}
          >
            <Card className="h-full bg-[#ff007f] border-[#ff007f] text-white">
              <CardHeader>
                <CardTitle className="text-white">ENVIE UMA MENSAGEM</CardTitle>
                <CardDescription className="text-pink-100/90">
                  Preencha o formulário abaixo para entrar em contato diretamente.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-white">Nome</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Seu nome" 
                                {...field} 
                                className="bg-white/10 border-white/20 text-white focus-visible:ring-white"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-white">Email</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="seu-email@example.com" 
                                type="email" 
                                {...field} 
                                className="bg-white/10 border-white/20 text-white focus-visible:ring-white"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="subject"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-white">Assunto</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Assunto da mensagem" 
                              {...field} 
                              className="bg-white/10 border-white/20 text-white focus-visible:ring-white"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="message"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-white">Mensagem</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Sua mensagem..." 
                              {...field} 
                              className="min-h-32 bg-white/10 border-white/20 text-white focus-visible:ring-white"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button 
                      type="submit" 
                      className="w-full bg-white text-[#ff007f] hover:bg-white/90"
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? "Enviando..." : "Enviar Mensagem"}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
};

export default Contact;
