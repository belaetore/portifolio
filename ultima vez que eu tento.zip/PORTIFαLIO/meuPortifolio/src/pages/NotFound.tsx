
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";

const NotFound = () => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="text-center max-w-md"
      >
        <h1 className="text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-200 to-pink-400 mb-4">
          404
        </h1>
        <h2 className="text-2xl font-semibold text-pink-200 mb-4">Página não encontrada</h2>
        <p className="text-gray-300 mb-8">
          Parece que essa página desapareceu como se tivesse usado um feitiço de invisibilidade. Vamos te levar de volta ao caminho certo.
        </p>
        <div className="flex justify-center">
          <Button
            asChild
            className="bg-gradient-to-r from-pink-700 to-pink-500 hover:from-pink-600 hover:to-pink-400 border-none"
          >
            <Link to="/">Voltar ao Início</Link>
          </Button>
        </div>
        <div className="mt-8 text-pink-400 opacity-60">
          <span className="inline-block animate-pulse">✨</span>
        </div>
      </motion.div>
    </div>
  );
};

export default NotFound;
